-- Rode este arquivo inteiro no Supabase: SQL Editor > New query > Run

create table if not exists public.groups (
  id uuid primary key,
  data jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

-- Segurança: ninguém acessa a tabela diretamente (sem policies).
-- O app só consegue ler/gravar um grupo se souber o ID dele (o ID vai no link).
alter table public.groups enable row level security;

create or replace function public.get_group(p_id uuid)
returns jsonb
language sql
security definer
set search_path = public
as $$
  select data from public.groups where id = p_id;
$$;

create or replace function public.save_group(p_id uuid, p_data jsonb)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  if pg_column_size(p_data) > 200000 then
    raise exception 'grupo grande demais';
  end if;
  insert into public.groups (id, data, updated_at)
  values (p_id, p_data, now())
  on conflict (id) do update set data = excluded.data, updated_at = now();
end;
$$;

revoke all on function public.get_group(uuid) from public;
revoke all on function public.save_group(uuid, jsonb) from public;
grant execute on function public.get_group(uuid) to anon;
grant execute on function public.save_group(uuid, jsonb) to anon;
